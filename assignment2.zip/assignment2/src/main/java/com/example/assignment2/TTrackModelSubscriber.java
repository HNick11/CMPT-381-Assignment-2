package com.example.assignment2;

public interface TTrackModelSubscriber {
    void modelUpdated();
}
